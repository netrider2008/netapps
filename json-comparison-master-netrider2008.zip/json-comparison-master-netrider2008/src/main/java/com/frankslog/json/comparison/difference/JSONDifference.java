package com.frankslog.json.comparison.difference;

public interface JSONDifference {
	
	public String getMessage();
	
}
