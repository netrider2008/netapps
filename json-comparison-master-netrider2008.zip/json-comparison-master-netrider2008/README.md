# json-comparison

This library allows you to compare two JSON strings and get their differences (modeled in Java), so you can make assertions on them. It can be used in automated tests to compare the actual JSON response from a Web Service against a JSON from a file.

Check the sample test SampleDogComparisonTest.

You can read more about it on my blog https://frankslogblog.wordpress.com/2017/04/18/a-new-approach-to-testing/
