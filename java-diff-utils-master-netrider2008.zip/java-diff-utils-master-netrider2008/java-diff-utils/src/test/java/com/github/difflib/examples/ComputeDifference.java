package com.github.difflib.examples;

import com.github.difflib.DiffUtils;
import com.github.difflib.TestConstants;
import com.github.difflib.patch.AbstractDelta;
import com.github.difflib.patch.Patch;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

public class ComputeDifference {

    private static final String ORIGINAL = "C:\\Users\\Mr Gaurav Rajapurkar\\Downloads\\json-comparison-master\\src\\test\\resources\\dogs\\get\\actualDog.json";
    private static final String RIVISED = "C:\\Users\\Mr Gaurav Rajapurkar\\Downloads\\json-comparison-master\\src\\test\\resources\\dogs\\get2\\actualDog.json";
    private static final String ORIGINALF = new String("C:\\Users\\Mr Gaurav Rajapurkar\\Downloads\\json-comparison-master\\src\\test\\resources\\dogs\\get");
    private static final String RIVISEDF = new String("C:\\Users\\Mr Gaurav Rajapurkar\\Downloads\\json-comparison-master\\src\\test\\resources\\dogs\\get2");

    public static void main(String[] args) throws IOException {
        List<String> original = Files.readAllLines(new File(ORIGINAL).toPath());
        List<String> revised = Files.readAllLines(new File(RIVISED).toPath());

        // Compute diff. Get the Patch object. Patch is the container for computed deltas.
        Patch<String> patch = DiffUtils.diff(original, revised);

        for (AbstractDelta<String> delta : patch.getDeltas()) {
         //   System.out.println(delta);
        }
        
        List<File> files =Files.list(Paths.get(ORIGINALF))
                .map(Path::toFile)
                .collect(Collectors.toList());
     //   files.forEach(System.out::println);
        List<File> revisedfiles =Files.list(Paths.get(RIVISEDF))
                .map(Path::toFile)
                .collect(Collectors.toList());
     //   revisedfiles.forEach(System.out::println);
        
        for(int i =0; i <revisedfiles.size();i++)
        {
        String originalFileName =files.get(i).getAbsolutePath();
        String revisedFileName = revisedfiles.get(i).getAbsolutePath();
        System.out.println(originalFileName);
        System.out.println(revisedFileName);

        original = Files.readAllLines(new File(originalFileName).toPath());
       revised = Files.readAllLines(new File(revisedFileName).toPath());
         patch = DiffUtils.diff(original, revised);

        for (AbstractDelta<String> delta : patch.getDeltas()) {
            System.out.println(delta);
        }
    }
}
}
